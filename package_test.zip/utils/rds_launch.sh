#!/bin/bash
mysql -h ${aws_db_endpoint} -u ${aws_db_user} -p 
