When at root:  


```python -m Sandbox.get_signals```