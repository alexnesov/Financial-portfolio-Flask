from utils.fetchData import fetchSignals


average, items, spSTART, spEND, nSignals, dfSignals = fetchSignals(ALL=True)


print(dfSignals)

"""
Get price at D+1, D+3, D+5
Then see by sector
Then see by market regime
Bayes?
"""

