from SV import db
from SV.models import User

db.create_all()

print("DB created.")